# Wedding Smart Card — Shravan & Nikki

This package contains Page 1 only.

## Files
- `index.html` — the single-page wedding card
- `assets/opening-door.jpg` — first still screen with the existing OPEN artwork
- `assets/opening-animation.mp4` — opening video
- `assets/final-curtain.jpg` — permanent still background after the video ends

## Page 1 behaviour
1. The first image stays still until the existing OPEN artwork is tapped.
2. The video plays once.
3. When the video ends, the supplied final still image appears permanently.
4. Wedding text fades in one item at a time.
5. The bottom buttons are included as visual placeholders. No date, date details, or additional pages have been created.

## Publish with GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html` and the complete `assets` folder (keep the folder structure).
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select **main** and **/(root)**, then Save.
6. Wait for GitHub Pages to publish and open the provided website link.

Only Page 1 is included. Additional pages can be added later, step by step.
